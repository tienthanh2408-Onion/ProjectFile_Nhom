<?php
session_start();

include("../config/database.php");

$message = "";

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users
    WHERE email='$email'
    AND password='$password'";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) > 0){

        $user = mysqli_fetch_assoc($result);

        $_SESSION['user'] = $user;

        header("Location: ../in.php");

    }else{
        $message = "Sai email hoặc mật khẩu";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">

    <h2>Đăng nhập</h2>

    <form method="POST">

        <input type="email"
        name="email"
        placeholder="Email">

        <input type="password"
        name="password"
        placeholder="Mật khẩu">

        <button type="submit"
        name="login">
            Đăng nhập
        </button>

    </form>

    <p class="error">
        <?php echo $message; ?>
    </p>

    <p>
        Chưa có tài khoản?
        <a href="register.php">Đăng ký</a>
    </p>

</div>

</body>
</html>