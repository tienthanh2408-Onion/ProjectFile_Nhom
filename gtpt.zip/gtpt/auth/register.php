<?php
include("../config/database.php");

$message = "";

if(isset($_POST['register'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];

    if(
        empty($fullname) ||
        empty($email) ||
        empty($password) ||
        empty($phone)
    ){
        $message = "Vui lòng nhập đầy đủ thông tin";
    }else{

        $check = mysqli_query($conn,
        "SELECT * FROM users WHERE email='$email'");

        if(mysqli_num_rows($check) > 0){
            $message = "Email đã tồn tại";
        }else{

            $sql = "INSERT INTO users
            (fullname,email,password,phone)
            VALUES
            ('$fullname','$email','$password','$phone')";

            if(mysqli_query($conn,$sql)){
                $message = "Đăng ký thành công";
            }else{
                $message = "Đăng ký thất bại";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Đăng ký</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">

    <h2>Đăng ký tài khoản</h2>

    <form method="POST">

        <input type="text"
        name="fullname"
        placeholder="Họ tên">

        <input type="email"
        name="email"
        placeholder="Email">

        <input type="password"
        name="password"
        placeholder="Mật khẩu">

        <input type="text"
        name="phone"
        placeholder="Số điện thoại">

        <button type="submit"
        name="register">
            Đăng ký
        </button>

    </form>

    <p class="error">
        <?php echo $message; ?>
    </p>

    <p>
        Đã có tài khoản?
        <a href="login.php">Đăng nhập</a>
    </p>

</div>

</body>
</html>