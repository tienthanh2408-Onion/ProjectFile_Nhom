<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "GTPT"
);

if(!$conn){
    die("Kết nối thất bại");
}

?>